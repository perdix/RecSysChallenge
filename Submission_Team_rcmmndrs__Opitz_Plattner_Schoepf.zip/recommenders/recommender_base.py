import logging

class RecommenderBase:

    def __init__(self):
        self.is_setup = False

